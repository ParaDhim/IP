def function1():
def generateData():