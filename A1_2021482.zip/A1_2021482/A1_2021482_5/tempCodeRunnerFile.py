def checkPalindrome(n):
# def checkNarcissistic(n):
# def findDigitSum(n):
# def findSquareD