
print(l)